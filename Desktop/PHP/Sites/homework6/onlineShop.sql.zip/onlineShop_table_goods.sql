
-- --------------------------------------------------------

--
-- Table structure for table `goods`
--

CREATE TABLE `goods` (
  `id_product` int(255) NOT NULL,
  `name_product` varchar(255) NOT NULL,
  `img_dir` varchar(255) NOT NULL,
  `description_short` varchar(255) NOT NULL,
  `price_product` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `goods`
--

INSERT INTO `goods` (`id_product`, `name_product`, `img_dir`, `description_short`, `price_product`) VALUES
(1, 'blue shoes', 'image1', 'blablablablablablablablablablabbalab', '500$'),
(2, 'leopard shoes', 'image2', 'blablablablablablablablablablabbalab', '500$'),
(3, 'man brown shoes', 'image3', 'blablablablablablablablablablabbalab', '500$'),
(4, 'snikers nike', 'image3', 'blablablablablablablablablablabbalab', '500$'),
(5, 'crazy shoes', 'image4', 'blablablablablablablablablablabbalab', '500$'),
(6, 'black sandales', 'image6', 'blablablablablablablablablablabbalab', '500$'),
(7, 'black high heals shoes', 'image7', 'blablablablablablablablablablabbalab', '500$'),
(8, 'red shoes', 'image8', 'blablablablablablablablablablabbalab', '500$'),
(9, 'black closed shoes', 'image9', 'blablablablablablablablablablabbalab', '500$');
