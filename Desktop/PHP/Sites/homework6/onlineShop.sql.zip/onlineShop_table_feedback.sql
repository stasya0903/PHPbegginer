
-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id_feedback` int(255) NOT NULL,
  `User_name` varchar(255) NOT NULL,
  `feedback` varchar(255) NOT NULL,
  `timestamp` varchar(255) NOT NULL,
  `id_product` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id_feedback`, `User_name`, `feedback`, `timestamp`, `id_product`) VALUES
(1, 'Светлана', 'Шикарнишие туфли', '12 November 2019 ', 2),
(2, 'Anastasia', 'Очень комфортные и качество идеальное!', '12 November 2019 ', 2),
(3, 'Елена', 'Я в восторге!', '12 November 2019 ', 2),
(4, 'Виктория', 'Безумно красивые, но не для ежедневной носки ', '12 November 2019 ', 1),
(5, 'Виктория', 'Безумно красивые, но не для ежедневной носки ', '12 November 2019 ', 1),
(6, 'Владимир', 'Очень удобные!', '12 November 2019 ', 3),
(7, 'Владимир', 'Очень удобные!', '12 November 2019 ', 3),
(8, 'Костя', 'Мне очень понравились!', '12 November 2019 ', 3),
(9, 'Костя', 'Мне очень понравились!', '12 November 2019 ', 3),
(10, 'Костя', 'Мне очень понравились!', '12 November 2019 ', 3),
(11, 'Костя', 'Мне очень понравились!', '12 November 2019 ', 3),
(12, 'Костя', 'Мне очень понравились!', '12 November 2019 ', 3),
(13, 'Светлана', 'Шикарные туфли!', '12 November 2019 ', 8),
(14, 'Светлана', 'Мне очень понравилось', '12 November 2019 ', 8);
